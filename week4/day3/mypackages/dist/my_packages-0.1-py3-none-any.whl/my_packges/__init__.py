class name:
    def name(self,name):
        self.name=name
    
    def get_name(self):
        name=input("enter your name")
        print(name)

