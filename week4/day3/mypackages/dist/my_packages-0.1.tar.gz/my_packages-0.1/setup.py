from setuptools import setup
setup(
    name='my_packages',
    version='0.1',
    author='Devarsh Mehta',
    description='Simple custom packages',
    packages=['my_packges'] 
)